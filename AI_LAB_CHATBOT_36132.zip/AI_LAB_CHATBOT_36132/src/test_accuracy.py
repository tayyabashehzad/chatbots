# src/test_accuracy.py
import csv
import os
from chatbot import FinMate, normalize_text  # <-- IMPORT normalize_text

bot = FinMate()

test_path = os.path.join(os.path.dirname(__file__), "..", "data", "test_set.csv")

total = 0
correct_intent = 0
mismatches = []

with open(test_path, newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        q = row['question'].strip()
        expected = row['expected_intent'].strip()
        total += 1

        # Preprocess question using global normalize_text
        norm_q = normalize_text(q)

        # Vectorize
        x_vec = bot.vec.transform([norm_q])

        # Predict intent
        try:
            if hasattr(bot.clf, "predict_proba"):
                proba = bot.clf.predict_proba(x_vec)[0]
                pred_idx = int(proba.argmax())
                pred_intent = bot.le.inverse_transform([pred_idx])[0]
            else:
                pred_intent = bot.le.inverse_transform(
                    [int(bot.clf.predict(x_vec)[0])]
                )[0]
        except Exception:
            pred_intent = "error"

        # Check accuracy
        if pred_intent == expected:
            correct_intent += 1
        else:
            mismatches.append((q, expected, pred_intent))

# Print results
acc = correct_intent / total * 100 if total else 0
print(f"Intent accuracy: {correct_intent}/{total} = {acc:.1f}%")
print("\nSample mismatches (up to 10):")
for m in mismatches[:10]:
    print("-", m)
