# src/train.py (debug-friendly + SBERT embeddings)
import pandas as pd
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
import os
import sys
import traceback
import numpy as np

# Optional: sentence-transformers (for semantic embeddings)
try:
    from sentence_transformers import SentenceTransformer
    SBERT_AVAILABLE = True
except Exception:
    SBERT_AVAILABLE = False

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "qa.csv")
ARTIFACTS_DIR = os.path.join(os.path.dirname(__file__), "models")
os.makedirs(ARTIFACTS_DIR, exist_ok=True)

def load_data(path=DATA_PATH):
    print("DEBUG: reading data from:", os.path.abspath(path))
    # list files in data folder for extra debugging
    data_dir = os.path.dirname(path)
    try:
        print("DEBUG: files in data folder:", os.listdir(data_dir))
    except Exception as e:
        print("DEBUG: could not list data folder:", e)

    # Try reading with common options if default fails
    read_attempts = [
        {"path": path, "kwargs": {}},
        {"path": path, "kwargs": {"encoding": "utf-8"}},
        {"path": path, "kwargs": {"encoding": "utf-8-sig"}},
        {"path": path, "kwargs": {"engine": "python"}}
    ]

    last_exc = None
    for attempt in read_attempts:
        try:
            df = pd.read_csv(attempt["path"], **attempt["kwargs"])
            print(f"DEBUG: read_csv succeeded with kwargs={attempt['kwargs']}")
            break
        except Exception as e:
            last_exc = e
            print(f"DEBUG: read_csv failed with kwargs={attempt['kwargs']} -> {type(e).__name__}: {e}")
            continue
    else:
        # if loop completes without break
        print("ERROR: All attempts to read CSV failed. Showing last exception:")
        traceback.print_exception(type(last_exc), last_exc, last_exc.__traceback__, file=sys.stdout)
        raise last_exc

    print("DEBUG: raw dataframe columns:", list(df.columns))
    # try to coerce header names (strip spaces, lower)
    df.columns = [c.strip() for c in df.columns]
    expected = ['question', 'answer', 'intent']
    for c in expected:
        if c not in [col.lower() for col in df.columns]:
            raise ValueError(f"CSV missing required column: {c}. Found columns: {list(df.columns)}")

    # map columns to expected names (case-insensitive)
    cols_map = {}
    for col in df.columns:
        cl = col.lower()
        if cl in expected:
            cols_map[cl] = col  # original name

    df_clean = pd.DataFrame()
    df_clean['question'] = df[cols_map['question']].astype(str)
    df_clean['answer'] = df[cols_map['answer']].astype(str)
    df_clean['intent'] = df[cols_map['intent']].astype(str)

    print("Loaded data shape:", df_clean.shape)
    print("Sample rows:")
    print(df_clean.head(8).to_string(index=False))
    return df_clean

def train_and_save():
    try:
        df = load_data()
        X = df['question'].values
        y = df['intent'].values

        vec = TfidfVectorizer(ngram_range=(1,2), min_df=1)
        X_vec = vec.fit_transform(X)

        le = LabelEncoder()
        y_enc = le.fit_transform(y)

        clf = LogisticRegression(max_iter=1000)
        clf.fit(X_vec, y_enc)

        answer_obj = {
            "questions": df['question'].tolist(),
            "answers": df['answer'].tolist(),
            "intents": df['intent'].tolist(),
            "answer_vecs": X_vec  # sparse matrix (TF-IDF) for fallback
        }

        # If SBERT is available, compute dense embeddings for semantic retrieval
        if SBERT_AVAILABLE:
            try:
                print("INFO: Sentence-Transformers available — computing SBERT embeddings (this may take a moment)...")
                sbert = SentenceTransformer("all-MiniLM-L6-v2")
                question_embeddings = sbert.encode(answer_obj["questions"], show_progress_bar=True, convert_to_numpy=True)
                # store as numpy array inside answer_obj
                answer_obj["question_embeddings"] = question_embeddings
                print("INFO: SBERT embeddings computed and added to artifacts.")
            except Exception as e:
                print("WARNING: Failed to compute SBERT embeddings:", e)
                print("Proceeding without dense embeddings. To enable, install 'sentence-transformers' and try again.")
        else:
            print("INFO: sentence-transformers not installed. To enable semantic search, run: pip install -U sentence-transformers")

        # save artifacts
        with open(os.path.join(ARTIFACTS_DIR, "tfidf.pkl"), "wb") as f:
            pickle.dump(vec, f)
        with open(os.path.join(ARTIFACTS_DIR, "clf.pkl"), "wb") as f:
            pickle.dump(clf, f)
        with open(os.path.join(ARTIFACTS_DIR, "le.pkl"), "wb") as f:
            pickle.dump(le, f)
        with open(os.path.join(ARTIFACTS_DIR, "answers.pkl"), "wb") as f:
            pickle.dump(answer_obj, f)

        print("Training complete. Artifacts saved to", ARTIFACTS_DIR)
    except Exception as e:
        print("\n=== TRAINING FAILED ===")
        traceback.print_exception(type(e), e, e.__traceback__, file=sys.stdout)
        print("Please copy the full error above and paste it here so I can debug further.")
        raise

if __name__ == "__main__":
    train_and_save()
