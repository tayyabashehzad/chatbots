# src/chatbot.py
import os
import pickle
import re
import random
import numpy as np
import csv
from datetime import datetime
from sklearn.metrics.pairwise import cosine_similarity

# NLP utils
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)
nltk.download('omw-1.4', quiet=True)

# Optional SBERT
try:
    from sentence_transformers import SentenceTransformer
    SBERT_INSTALLED = True
except Exception:
    SBERT_INSTALLED = False

ARTIFACTS_DIR = os.path.join(os.path.dirname(__file__), "models")
LOG_DIR = os.path.join(os.path.dirname(__file__), "..", "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# Conversational templates
TEMPLATES = {
    "definition": [
        "Sure — here's a short explanation: {}",
        "In short: {}",
        "{}. Want an example or a simple tip related to this?"
    ],
    "saving": [
        "{}",
        "{}. Would you like a short 3-step plan to start?",
        "Here's an idea: {}. Want tips to automate this?"
    ],
    "budgeting": [
        "{}",
        "{}. Want a simple template you can use monthly?"
    ],
    "investing": [
        "{}",
        "{}. Want safer beginner-friendly options?"
    ],
    "calculation": [
        "{}",
        "{}. Need this converted to a different currency or amount?"
    ],
    "fallback": [
        "{}",
        "{}. Can you rephrase or choose from suggestions below?"
    ],
    "generic": [
        "{}",
        "{}. Is that helpful?"
    ]
}

# smalltalk shortcuts
GREETINGS = {"hi","hello","hey","assalam","good morning","good evening"}
FAREWELL = {"bye","goodbye","exit","quit","see you"}
THANKS = {"thanks","thank you","thx","ty"}

# Out-of-syllabus (out-of-scope) keywords — easily extend this list
OUT_OF_SCOPE_KEYWORDS = {
    "germany","uk","usa","united states","india","canada","australia",
    "tax","taxes","filing taxes","visa","immigration","passport","legal",
    "law","court","divorce","criminal","driving license","driving licence",
    "medical treatment","prescription","prescribe","surgery"
}

# preprocessing helpers
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

# SAFE fallback tokenizer
def safe_tokenize(text):
    return re.findall(r"\d+\.\d+|\d+%?|\w+", text)

def normalize_text(text):
    text = text.lower().strip()
    text = re.sub(r"[^\w\s\.\:\%]", " ", text)
    try:
        tokens = nltk.word_tokenize(text)
    except:
        tokens = safe_tokenize(text)
    tokens = [lemmatizer.lemmatize(t) for t in tokens if t not in stop_words]
    return " ".join(tokens)

# Logging helpers
def log_unknown(question, reason="unknown"):
    path = os.path.join(LOG_DIR, "unknown_queries.csv")
    header_needed = not os.path.exists(path)
    with open(path, "a", newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if header_needed:
            writer.writerow(["timestamp_utc", "question", "reason"])
        writer.writerow([datetime.utcnow().isoformat(), question, reason])

def log_out_of_scope(question, matched_keyword):
    path = os.path.join(LOG_DIR, "out_of_scope.csv")
    header_needed = not os.path.exists(path)
    with open(path, "a", newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if header_needed:
            writer.writerow(["timestamp_utc", "question", "matched_keyword"])
        writer.writerow([datetime.utcnow().isoformat(), question, matched_keyword])

class FinMate:
    def __init__(self, intent_conf_threshold=0.6, sbert_threshold=0.55):
        # load artifacts (assumes train.py has been run)
        with open(os.path.join(ARTIFACTS_DIR, "tfidf.pkl"), "rb") as f:
            self.vec = pickle.load(f)
        with open(os.path.join(ARTIFACTS_DIR, "clf.pkl"), "rb") as f:
            self.clf = pickle.load(f)
        with open(os.path.join(ARTIFACTS_DIR, "le.pkl"), "rb") as f:
            self.le = pickle.load(f)
        with open(os.path.join(ARTIFACTS_DIR, "answers.pkl"), "rb") as f:
            obj = pickle.load(f)
            self.questions = obj["questions"]
            self.answers = obj["answers"]
            self.intents = obj["intents"]
            self.answer_vecs = obj.get("answer_vecs")  # TF-IDF sparse matrix

            # try to load precomputed SBERT embeddings if present
            stored_emb = obj.get("question_embeddings", None)
            if stored_emb is not None:
                self.question_embeddings = np.asarray(stored_emb)
                print(f"INFO: Loaded precomputed SBERT embeddings shape={self.question_embeddings.shape}")
            else:
                self.question_embeddings = None

        self.intent_conf_threshold = intent_conf_threshold
        self.sbert_threshold = sbert_threshold

        # follow-up state values: None, "saving_plan", "give_example"
        self.awaiting_followup = None

        # load SBERT model if installed and embeddings missing — compute on startup
        self.sbert = None
        if SBERT_INSTALLED and self.question_embeddings is None:
            try:
                print("INFO: SBERT installed but embeddings not found in artifacts — computing embeddings now (startup cost).")
                self.sbert = SentenceTransformer("all-MiniLM-L6-v2")
                emb = self.sbert.encode(self.questions, show_progress_bar=True, convert_to_numpy=True)
                self.question_embeddings = np.asarray(emb)
                print("INFO: Computed SBERT embeddings; future startups will be faster if embeddings are saved in train.py.")
            except Exception as e:
                print("WARNING: Failed to compute SBERT embeddings at startup:", e)
                self.question_embeddings = None
        elif SBERT_INSTALLED and self.question_embeddings is not None:
            # we can still init the model lazily when needed
            try:
                self.sbert = SentenceTransformer("all-MiniLM-L6-v2")
            except Exception:
                self.sbert = None

    # small calculators
    def _calc_return(self, text):
        m = re.search(r"buy[:\s]*([0-9]+(?:\.[0-9]+)?)\s*[,;\s]*sell[:\s]*([0-9]+(?:\.[0-9]+)?)", text.lower())
        if m:
            buy = float(m.group(1))
            sell = float(m.group(2))
            ret = (sell - buy) / buy * 100.0
            return f"Return = {ret:.2f}% (buy={buy}, sell={sell})"
        return None

    def _calc_savings_target(self, text):
        # matches "save 60000 in 6 months" or "save 60,000 in 6 months"
        m = re.search(r"save[s]?[\s\:]*([\d,]+)\s*(?:in)?\s*([0-9]+)\s*months?", text.lower())
        if m:
            target = float(m.group(1).replace(",", ""))
            months = int(m.group(2))
            monthly = target / months
            return f"To reach {int(target):,} in {months} months you need to save {monthly:,.0f} per month."
        return None

    # simple out-of-syllabus detection by keyword
    def _detect_out_of_scope(self, text):
        low = text.lower()
        for kw in OUT_OF_SCOPE_KEYWORDS:
            if kw in low:
                return kw
        return None

    def _choose_template(self, intent, text):
        return random.choice(TEMPLATES.get(intent, TEMPLATES["generic"])).format(text)

    def _top_similar_questions(self, x_vec, topk=3):
        # if dense embeddings available, use them for top suggestions, else use TF-IDF fallback
        if self.question_embeddings is not None:
            try:
                # if x_vec is TF-IDF vector, we cannot use directly; compute SBERT for suggestions externally if needed
                # This helper expects x_vec to be a dense vector (embedding) — so caller should pass embedding
                sims = cosine_similarity(x_vec, self.question_embeddings)[0]
                idxs = np.argsort(sims)[::-1][:topk]
                return [(self.questions[i], float(sims[i])) for i in idxs]
            except Exception:
                pass

        # fallback: use TF-IDF similarity with stored answer_vecs
        try:
            sims = cosine_similarity(x_vec, self.answer_vecs)[0]
            idxs = np.argsort(sims)[::-1][:topk]
            return [(self.questions[i], float(sims[i])) for i in idxs]
        except Exception:
            # as absolute fallback return first few questions
            return [(q, 0.0) for q in self.questions[:topk]]

    def reply(self, text):
        text = text.strip()
        if not text:
            return "Please type something so I can help."

        low = text.lower()

        # handle followup state first (short replies)
        if self.awaiting_followup:
            if self.awaiting_followup == "saving_plan" and low in {"yes","yes please","please","sure","yep","ya","ok","okay"}:
                self.awaiting_followup = None
                return ("Great — here is a simple 3-step plan:\n"
                        "1) Track your expenses for one month.\n"
                        "2) Cut one non-essential expense and move that amount to savings.\n"
                        "3) Automate a monthly transfer to your savings account.\n"
                        "Would you like a numeric example?")
            if self.awaiting_followup == "give_example" and (low.startswith("yes") or "example" in low or low in {"please","sure"}):
                self.awaiting_followup = None
                return "Example: If bread cost 100 PKR last year and inflation is 10%, it costs 110 PKR this year."
            # if user says something else while awaiting, clear state and continue normally
            self.awaiting_followup = None

        # smalltalk shortcuts
        if low in GREETINGS:
            return random.choice(["Hi! I'm FinMate — ask me anything about savings, budgeting, or money tips."])
        if any(w in low for w in THANKS):
            return random.choice(["You're welcome! 😊", "No problem — happy to help!"])
        if low in FAREWELL:
            return random.choice(["Goodbye! Stay smart with your money.", "See you — good luck!"])

        # OUT-OF-SYLLABUS detection (country-specific/legal/medical etc.)
        oos_kw = self._detect_out_of_scope(text)
        if oos_kw:
            # log and respond politely
            log_out_of_scope(text, oos_kw)
            return (f"Sorry — I don't have reliable information about '{oos_kw}' topics (legal/tax/visa/medical) right now. "
                    "I focus on general personal finance (budgeting, saving, basic investing). "
                    "If you want, I can log this question for future updates.")

        # quick numeric checks
        calc = self._calc_return(text)
        if calc:
            return calc
        savings_calc = self._calc_savings_target(text)
        if savings_calc:
            return savings_calc

        # Preprocess and TF-IDF vectorize
        norm = normalize_text(text)
        x_tfidf = self.vec.transform([norm])

        # classifier prediction (intent)
        intent = None
        intent_conf = 0.0
        try:
            if hasattr(self.clf, "predict_proba"):
                proba = self.clf.predict_proba(x_tfidf)[0]
                pred_idx = int(np.argmax(proba))
                intent_conf = float(proba[pred_idx])
            else:
                pred_idx = int(self.clf.predict(x_tfidf)[0])
                intent_conf = 1.0
            intent = str(self.le.inverse_transform([pred_idx])[0])
        except Exception:
            intent = None
            intent_conf = 0.0

        # --- HYBRID RETRIEVAL LOGIC ---

        # 1) If SBERT embeddings available, try dense retrieval (optionally filtered by intent)
        if self.question_embeddings is not None:
            try:
                # ensure SBERT model ready
                if self.sbert is None and SBERT_INSTALLED:
                    try:
                        self.sbert = SentenceTransformer("all-MiniLM-L6-v2")
                    except Exception:
                        self.sbert = None

                if self.sbert is not None:
                    query_emb = self.sbert.encode([text], convert_to_numpy=True)
                    # if classifier confident, restrict to same-intent candidates (hybrid)
                    if intent and intent_conf >= self.intent_conf_threshold:
                        idxs = [i for i, it in enumerate(self.intents) if it == intent]
                        if idxs:
                            sub_embs = self.question_embeddings[idxs]
                            sims = cosine_similarity(query_emb, sub_embs)[0]
                            best_local = int(np.argmax(sims))
                            best_idx = idxs[best_local]
                            best_score = float(sims[best_local])
                            if best_score >= self.sbert_threshold:
                                ans = self.answers[best_idx]
                                reply = self._choose_template(self.intents[best_idx], ans)
                                # set followup if needed
                                if self.intents[best_idx] in {"saving", "budgeting", "investing"}:
                                    reply = reply + " Would you like a short 3-step plan?"
                                    self.awaiting_followup = "saving_plan"
                                return reply + f"  \n\n(semantic_sim={best_score:.2f}, intent={intent}, intent_conf={intent_conf:.2f})"
                    # else: dense retrieval across all questions
                    sims_all = cosine_similarity(query_emb, self.question_embeddings)[0]
                    best_idx_all = int(np.argmax(sims_all))
                    best_score_all = float(sims_all[best_idx_all])
                    if best_score_all >= self.sbert_threshold:
                        ans = self.answers[best_idx_all]
                        reply = self._choose_template(self.intents[best_idx_all], ans)
                        # set followup if needed
                        if self.intents[best_idx_all] in {"saving", "budgeting", "investing"}:
                            reply = reply + " Would you like a short 3-step plan?"
                            self.awaiting_followup = "saving_plan"
                        return reply + f"  \n\n(semantic_sim={best_score_all:.2f})"
            except Exception as e:
                # if anything goes wrong with SBERT, ignore and continue to TF-IDF fallback
                print("WARNING: SBERT retrieval failed, falling back to TF-IDF. Error:", e)

        # 2) If SBERT didn't return good answer, try TF-IDF intent-first logic (existing behaviour)
        if intent and intent_conf >= self.intent_conf_threshold:
            idxs = [i for i, it in enumerate(self.intents) if it == intent]
            if idxs:
                try:
                    sub_vecs = self.answer_vecs[idxs]
                    sims = cosine_similarity(x_tfidf, sub_vecs)[0]
                    best_local = int(np.argmax(sims))
                    chosen_idx = idxs[best_local]
                    ans = self.answers[chosen_idx]
                    reply = self._choose_template(intent, ans)
                    if intent in {"saving", "budgeting", "investing"}:
                        reply = reply + " Would you like a short 3-step plan?"
                        self.awaiting_followup = "saving_plan"
                    return reply + f"  \n\n(intent={intent}, confidence={intent_conf:.2f})"
                except Exception:
                    pass

        # 3) fallback: TF-IDF similarity across all stored questions
        try:
            sims_all = cosine_similarity(x_tfidf, self.answer_vecs)[0]
            best_idx = int(np.argmax(sims_all))
            best_score = float(sims_all[best_idx])
            if best_score >= 0.30:
                ans = self.answers[best_idx]
                intent_here = self.intents[best_idx]
                reply = self._choose_template(intent_here, ans)
                return reply + f"  \n\n(similarity={best_score:.2f}, intent_conf={intent_conf:.2f})"
        except Exception:
            pass

        # 4) Low-confidence / unknown: log and respond gracefully
        log_unknown(text, reason="low_confidence")
        # prepare suggestions: prefer semantic suggestions if embeddings exist
        if self.question_embeddings is not None and self.sbert is not None:
            try:
                query_emb = self.sbert.encode([text], convert_to_numpy=True)
                suggestions = self._top_similar_questions(query_emb, topk=3)
            except Exception:
                suggestions = self._top_similar_questions(x_tfidf, topk=3)
        else:
            suggestions = self._top_similar_questions(x_tfidf, topk=3)

        sug_text = "\n".join([f"- {q} (match={s:.2f})" for q, s in suggestions])
        return (
            "I’m sorry — I don’t have a confident answer for that phrasing right now. "
            "I am still learning. Did you mean one of these?\n" + sug_text +
            "\n\nIf none match, please try rephrasing or ask a simpler question like 'How can I save money?'."
        )

if __name__ == "__main__":
    bot = FinMate()
    print("FinMate: Hi! Ask me about savings, budgeting, investing, or type 'buy 100 sell 120'.")
    while True:
        try:
            text = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nFinMate: Goodbye!")
            break
        if text.lower() in {"exit", "quit"}:
            print("FinMate: Goodbye!")
            break
        print("FinMate:", bot.reply(text))
