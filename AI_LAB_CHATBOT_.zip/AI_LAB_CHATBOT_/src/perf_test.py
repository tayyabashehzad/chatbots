# src/perf_test.py
import time, csv
from chatbot import FinMate

bot = FinMate()
# test queries (you can expand)
queries = [
  "How can I save money?",
  "What is inflation?",
  "Explain stock market",
  "How to start investing?",
  "I want to save 60000 in 6 months. How much per month?"
] * 10  # 5 queries repeated -> 50 queries total

times = []
for q in queries:
    t0 = time.time()
    _ = bot.reply(q)
    t1 = time.time()
    times.append((t1 - t0))
avg_ms = sum(times) / len(times) * 1000
print(f"Ran {len(times)} queries. Average latency = {avg_ms:.1f} ms")
print("Min:", min(times)*1000, "ms  Max:", max(times)*1000, "ms")
