# src/app_streamlit.py
import streamlit as st
from chatbot import FinMate

st.set_page_config(page_title="FinMate - Offline Finance Chatbot", page_icon="💰")
st.title("FinMate — Offline Personal Finance Chatbot")

if 'bot' not in st.session_state:
    st.session_state.bot = FinMate()
if 'history' not in st.session_state:
    st.session_state.history = []

user = st.text_input("Ask FinMate:", placeholder="Ask about budgeting, saving, or type 'buy 100 sell 120'")
if st.button("Send") and user:
    reply = st.session_state.bot.reply(user)
    st.session_state.history.append(("You", user))
    st.session_state.history.append(("FinMate", reply))

st.markdown("---")
for who, text in st.session_state.history[-20:]:
    if who == "You":
        st.markdown(f"**You:** {text}")
    else:
        st.markdown(f"**FinMate:** {text}")
